<?php
/**
 * migx
 *
 * @package migx
 * @language it
 */


$_lang['mig.tabs'] = 'Schede form';
$_lang['mig.columns'] = 'Colonne griglia';
$_lang['mig.btntext'] = 'Testo alternativo ad "Aggiungi Elemento"';
$_lang['mig.previewurl'] = 'Preview Url';
$_lang['mig.jsonvarkey'] = 'Preview JsonVarKey';
$_lang['mig.basepath'] = 'Base Path';
$_lang['mig.autoResourceFolders'] = 'Auto Resource Folders';